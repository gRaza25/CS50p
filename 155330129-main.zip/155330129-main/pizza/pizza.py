import sys
import csv
from tabulate import tabulate as t

def main():
    arg_check(sys.argv)
    convert(sys.argv[1])

def convert(arg):
    table = []
    try:
        with open(arg) as f:
            lines = csv.reader(f)
            for row in lines:
                table.append(row)

    except FileNotFoundError:
        sys.exit("File does not exist")

    print(t(table[1:], headers=table[0], tablefmt="grid"))

def arg_check(arg):
    if len(arg) < 2:
        sys.exit("Too few command-line arguments")
    elif len(arg) > 2:
        sys.exit("Too many command-line arguments")
    elif not arg[1].endswith(".csv"):
        sys.exit("Not a CSV file")

if __name__ == "__main__":
    main()
