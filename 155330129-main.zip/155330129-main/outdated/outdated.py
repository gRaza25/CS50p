months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

while True:
    user_date = input("Date: ").strip()
    try:
        mm, dd, yyyy = user_date.split("/")
        if (1 <= int(mm) <= 12) and (1 <= int(dd) <= 31):
            break

    except:
        try:
            mm2, dd2, yyyy = user_date.split(" ")
            for i in range(len(months)):
                if mm2 == months[i]:
                    mm = i + 1
            if not dd2.endswith(","):
                continue
            dd = dd2.replace(",", "")
            if (1 <= int(mm) <= 12) and (1 <= int(dd) <= 31):
                break
        except:
            pass

print(f"{yyyy}-{int(mm):02}-{int(dd):02}", end="")
