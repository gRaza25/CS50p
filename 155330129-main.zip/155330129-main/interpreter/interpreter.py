e = input("Expression: ")

x, y, z = e.split(" ")

x = float(x)
z = float (z)

if y == "+":
    result = x + z

if y == "-":
    result = x - z

if y == "*":
   result = x * z

if y == "/":
    result = x / z

print(round(result,1))

