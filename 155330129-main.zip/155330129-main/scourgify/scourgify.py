import sys
import csv


def main():

    if len(sys.argv) > 3:
        sys.exit('Too many command-line arguments')
    elif len(sys.argv) < 3:
        sys.exit('Too few command-line arguments')

    try:
        with open(sys.argv[1], 'r') as f:
            reader = csv.DictReader(f)
            with open(sys.argv[2], 'w') as f:
                fields = ['first', 'last', 'house']
                writer = csv.DictWriter(f, fieldnames=fields)
                writer.writeheader()
                for row in reader:
                    last, first = row['name'].split(",")
                    row['name'] = {'first': first.strip(),
                                   'last': last.strip()}

                    writer.writerow({'first': row['name']['first'],
                                     'last': row['name']['last'],
                                     'house': row['house']})
    except FileNotFoundError:
        sys.exit("Could not read invalid_file.csv")


if __name__ == "__main__":
    main()
