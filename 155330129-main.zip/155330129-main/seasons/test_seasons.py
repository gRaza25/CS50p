from seasons import calc_mins


def test_calc_mins():
    assert calc_mins(365) == "Five hundred twenty-five thousand, six hundred minutes"
    assert calc_mins(2) == "Two thousand, eight hundred eighty minutes"
    assert calc_mins(1) == "One thousand, four hundred forty minutes"
