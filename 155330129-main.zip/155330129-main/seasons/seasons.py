from datetime import date
import inflect
import operator
import sys

p = inflect.engine()


def main():
    birthdate = input("Date of birth: ")
    output = calc_diff(birthdate)
    print(output)


def calc_diff(d):
    try:
        difference = operator.sub(date.today(), date.fromisoformat(d))
        return calc_mins(difference.days)
    except ValueError:
        sys.exit("Invalid date")


def calc_mins(diff):
    mins = (diff) * 24 * 60
    return f"{(p.number_to_words(mins, andword="")).capitalize()} minutes"


if __name__ == "__main__":
    main()
