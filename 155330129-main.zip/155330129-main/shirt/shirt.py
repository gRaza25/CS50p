import sys
from os.path import splitext
from PIL import Image, ImageOps


def main():
    check_arg(sys.argv)
    try:
        img = Image.open(sys.argv[1])
    except FileNotFoundError:
        sys.exit("Input does not exist")
    shirt = Image.open("shirt.png")
    muppet = ImageOps.fit(img, shirt.size)
    muppet.paste(shirt, shirt)
    muppet.save(sys.argv[2])


def check_arg(arg):
    if len(arg) < 3:
        sys.exit("Too few command-line arguments")
    elif len(arg) > 3:
        sys.exit("Too many command-line arguments")
    file1 = splitext(arg[1])
    file2 = splitext(arg[2])
    if file2[1] not in (".jpg", ".jpeg", ".png"):
        sys.exit("Invalid output")
    if file1[1].lower() != file2[1].lower():
        sys.exit("Input and output have different extensions")


if __name__ == "__main__":
    main()
