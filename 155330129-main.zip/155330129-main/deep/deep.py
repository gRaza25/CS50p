# Ask the user the question
ans = input("What is the answer to the Great Question of Life, the Universe and Everything? ")

# Formatting the variable
ans = ans.lower()
ans = ans.strip()

# Check the input with the condition and print together
if ans == "42":
    print ("Yes")

elif ans == "forty-two":
    print ("Yes")

elif ans == "forty two":
    print ("Yes")

else:
    print("No")
