text = input("")
text = text.replace(" ","...")
print(text)
