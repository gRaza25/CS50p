# This program greets the user

name = input("What's your name? ")
print(f"Hello, {name}")
print("raza")
c=5
print(c)
