from sys import argv,exit


def main():
    argument_check(argv)
    print(lines(argv[1]))
def argument_check(arg):
    if len(arg) < 2:
        exit("Too few command-line arguments")
    elif len(arg) >2:
        exit("Too many command-line arguments")
    elif not arg[1].endswith(".py"):
        exit("Not a Python file")


def lines(file):
    count = 0
    try:
        with open (file) as f:
            for line in f:
                if not line.lstrip().startswith("#") and not line.isspace():
                    count += 1
    except FileNotFoundError:
        exit("File does not exist")
    return count

if __name__ == "__main__":
    main()
