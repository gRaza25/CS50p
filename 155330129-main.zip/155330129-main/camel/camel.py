camelcase = input("camelCase: ")
snake_case = ""
for c in camelcase:
    if c.isupper():
        snake_case += "_"
    snake_case += c
print(snake_case.lower())
