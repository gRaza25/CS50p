from numb3rs import validate


def main():
    test_format()
    test_numbers()


def test_format():
    assert validate(r"25.25.25.25") == True
    assert validate(r"25.25.25") == False
    assert validate(r"25.25") == False
    assert validate(r"25") == False
    assert validate(r"a.b.c.d") == False
    assert validate(r"a.25.25.25") == False


def test_numbers():
    assert validate(r"255.255.255.255") == True
    assert validate(r"240.245.250.256") == False
    assert validate(r"25.500.30.255") == False
    assert validate(r"25.18.600.56") == False
    assert validate(r"786.48.35.72") == False


if __name__ == "__main__":
    main()
