def main():
    convert()


def convert():
    text = input("")
    text = text.replace(":)","🙂")
    text = text.replace(":(", "🙁")
    print(text)

main()
