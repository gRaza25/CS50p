import pytest
from working import convert


def test_convert():
    assert convert("10 AM to 6 PM") == "10:00 to 18:00"
    assert convert("8:00 AM to 4:00 PM") == "08:00 to 16:00"
    assert convert("12 PM to 4 AM") == "12:00 to 04:00"
    assert convert("7:25 PM to 5:50 AM") == "19:25 to 05:50"

def test_value_error():
    with pytest.raises(ValueError):
        convert("8AM - 3PM")
    with pytest.raises(ValueError):
        convert("09:00 to 15:00")
    with pytest.raises(ValueError):
        convert("14:00 AM to 26:00 PM")
    with pytest.raises(ValueError):
        convert("7:60 AM to 4:60 PM")
