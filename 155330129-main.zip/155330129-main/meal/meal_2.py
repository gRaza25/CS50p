def main():
    time = input("Enter the time (#:## AM/PM or ##:## AM/PM): ")
    new_time = convert(time)

    if 7 <= new_time <= 8:
        print("breakfast time")

    elif 12 <= new_time <= 13:
        print("lunch time")

    elif 18 <= new_time <= 19:
        print("dinner time")


def convert(time):
    time_parts = time.split()
    h_m = time_parts[0].split(":")
    hours, minutes, period = (int(h_m[0]), int(h_m[1]), time_parts[1])
    if period.lower() == "pm" and hours != "12":
        hours += 12
    else:
        hours
    return (hours) + (minutes)/60


if __name__ == "__main__":
    main()
