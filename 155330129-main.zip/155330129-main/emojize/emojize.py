import emoji

answer = input("Input: ")

output = emoji.emojize(answer, language='alias')

print("Output:", output)
