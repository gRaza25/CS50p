text = input ("")
text = text.lower()
print(text)
