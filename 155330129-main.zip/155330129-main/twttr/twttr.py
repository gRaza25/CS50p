def main():
    text = input("Input: ")
    output = shorten(text)
    print("Output:", output)


def shorten(word):

    output = ""
    for c in word:
        if c.lower() in ["a", "e", "i", "o", "u"]:
            continue
        else:
            output += c

    return output


if __name__ == "__main__":
    main()
