def main():
    greeting = input("Greeting: ")
    output = value(greeting)
    print(output)

def value(g):
    g = g.strip().lower()
    if g.startswith("hello"):
        return int(100)

    elif g.startswith("h"):
        return int(20)

    else:
        return int(0)

if __name__ == "__main__":
    main()
