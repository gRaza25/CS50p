import pytest

from bank import value

def test_hello():
    assert value("Hello") == 100
def test_h():
    assert value("How are you") == 20
def test_noth():
    assert value("What’s up") == 0
