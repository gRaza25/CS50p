amount = 0
price = 50

while amount < price:
    coin = int(input("Insert Coin: "))
    if coin in [25, 10, 5]:
        amount += coin
        if amount < price:
            print(f"Amount Due: {price - amount}")
    else:
        print(f"Amount Due: {price - amount}")

change = amount - price
print(f"Change Owed: {change}")
