def main():
    fuel = input("Fraction: ")
    perc= convert(fuel)
    print(gauge(perc))

def convert(fraction):
    while True:
        try:
            x, y = fraction.split("/")
            x, y = int(x), int(y)
            ans = round((x/y) * 100)
            if ans <= 100:
                return ans
        except ValueError:
            raise(ValueError)
        except ZeroDivisionError:
            raise(ZeroDivisionError)

def gauge(percentage):
    if percentage <= 1:
        return ("E")
    elif percentage >= 99:
        return ("F")
    else :
        return (f"{percentage}%")

if __name__ == "__main__":
    main()
