import pytest

import fuel as f

def test_convert():
    assert f.convert("3/4") == 75
    assert f.convert("99/100") == 99
    assert f.convert("1/100") == 1

def test_gauge():
    assert f.gauge(99) == "F"
    assert f.gauge(1) == "E"
    assert f.gauge(35) == "35%"

def test_zero_division():
    with pytest.raises(ZeroDivisionError):
        f.convert("1/0")

def test_value_error():
    with pytest.raises(ValueError):
        f.convert("5/4")
