import pytest

from plates import is_valid

def test_num():
    assert is_valid("RAZ222") == True
    assert is_valid("RAZ22A") == False
    assert is_valid("RAZ022") == False
def test_length():
    assert is_valid("RAZA50") == True
    assert is_valid("RA") == True
    assert is_valid("RAZA2550") == False
def test_alphanum():
    assert is_valid("Ra25!") == False
def test_numstart():
    assert is_valid("2B") == False
    assert is_valid("BB") == True
    assert is_valid("B2") == False

    assert is_valid("AB2") == True
    assert is_valid("12") == False
    assert is_valid(" 2") == False
