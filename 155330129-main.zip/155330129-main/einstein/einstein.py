m = int(input("Enter the mass(m): "))
c = int(300000000)
E = m * (c ** 2)
print ("E is" , int(E))

