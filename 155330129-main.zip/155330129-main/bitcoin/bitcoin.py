import requests
import sys

def main():
    if len(sys.argv) == 2:
        try:
            n = float(sys.argv[1])
            print(btc_prc(n))
        except ValueError:
            sys.exit("Command-line argument is not a number")
    else:
        sys.exit("Missing command-line argument")

def btc_prc(num):
    try:
        response = requests.get(f"https://api.coindesk.com/v1/bpi/currentprice.json")
        result = response.json()
        prc = result["bpi"] ["USD"] ["rate_float"]
        total = prc * num
        return f"${total:,.4f}"
    except requests.RequestException:
        return None

main()
