# 🎥 **Youtube Channel Data Extractor**

## About the Project
This project, titled **Youtube Channel Data Extractor**, aims to extract essential data from Youtube channels efficiently.

## Developer
- **Name:** Mohammed Raza Govani
- **GitHub:** [gRaza25](https://github.com/gRaza25)
- **edX Username:** gRaza25

## Personal Details
- **Born City & Country:** Mahuva, Gujarat, India 🇮🇳
- **Current City:** Kinshasa, DRC 🇨🇩
- **Date Recorded:** 11/04/2024
